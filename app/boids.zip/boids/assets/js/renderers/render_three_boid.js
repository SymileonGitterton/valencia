// Your job is to implement this file
console.log(" IMPLEMENT ME! (OPEN ME, I HAVE HINTS) ");


/*

HINT 1: Copy render_three_particle.js. Rename it to render_three_boid.js. Then look for this section and implement your Prototype methods.
That's all you need to do. The section where you implement your code looks like this:

// ---------------------------------------------------------
// Particle Render Prototype Methods

*** implement your stuff here ***

// ------------------------------------------------------------------------------------------------
// Light

*/




/*

HINT 2: Look for this section inside render_processing_boid.js for inspiration. The section where you implement your code looks like this:

// ---------------------------------------------------------
// boids

*** use this part as a reference ***

// ---------------------------------------------------------
// setup

*/




/*

Finally, put the boids with three js renderer in your portfolio. This completes your training in introductory data visualization!

*/


